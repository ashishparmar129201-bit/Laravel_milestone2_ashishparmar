<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SubscriptionPlanController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('dashboard'));

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

// index, create, store, show, edit, update, destroy
Route::resource('subscriptions', SubscriptionPlanController::class);
