<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') | Subscription Manager</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        body { background: #f4f6fb; }
        .sidebar { min-height: 100vh; background: linear-gradient(180deg, #1e1b4b, #4338ca); }
        .sidebar .nav-link { color: rgba(255,255,255,.75); border-radius: .5rem; margin-bottom: .25rem; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { color: #fff; background: rgba(255,255,255,.15); }
        .stat-card { border: 0; border-radius: 1rem; box-shadow: 0 4px 14px rgba(0,0,0,.06); }
        .stat-icon { width: 52px; height: 52px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; }
        .card { border: 0; border-radius: 1rem; box-shadow: 0 4px 14px rgba(0,0,0,.06); }
        .price-tag { font-size: 2.5rem; font-weight: 700; }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">

        {{-- Sidebar (becomes a collapsible top menu on mobile) --}}
        <nav class="col-lg-2 col-md-3 sidebar p-3">
            <a href="{{ route('dashboard') }}" class="d-flex align-items-center text-white text-decoration-none mb-4">
                <i class="bi bi-layers-fill fs-3 me-2"></i>
                <span class="fs-5 fw-bold">PlanManager</span>
            </a>

            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">
                        <i class="bi bi-speedometer2 me-2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('subscriptions.index', 'subscriptions.show', 'subscriptions.edit') ? 'active' : '' }}" href="{{ route('subscriptions.index') }}">
                        <i class="bi bi-card-list me-2"></i> All Plans
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request()->routeIs('subscriptions.create') ? 'active' : '' }}" href="{{ route('subscriptions.create') }}">
                        <i class="bi bi-plus-circle me-2"></i> Add Plan
                    </a>
                </li>
            </ul>
        </nav>

        {{-- Main content --}}
        <main class="col-lg-10 col-md-9 p-4">
            @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle-fill me-1"></i> {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-1"></i> {{ session('error') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            @yield('content')
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
@stack('scripts')
</body>
</html>
