@extends('layouts.app')

@section('title', $plan->name)

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold mb-0">Plan Details</h3>
    <a href="{{ route('subscriptions.index') }}" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Back to Plans
    </a>
</div>

<div class="row g-4">
    {{-- Price / summary card --}}
    <div class="col-lg-4">
        <div class="card text-center h-100">
            <div class="card-body p-4">
                <span class="badge {{ $plan->status === 'Active' ? 'bg-success' : 'bg-secondary' }} mb-3">{{ $plan->status }}</span>
                <h4 class="fw-bold">{{ $plan->name }}</h4>
                <div class="price-tag text-primary my-3">${{ number_format($plan->price, 2) }}</div>
                <span class="badge bg-info-subtle text-info-emphasis fs-6">{{ $plan->duration }}</span>

                <hr class="my-4">

                <a href="{{ route('subscriptions.edit', $plan) }}" class="btn btn-primary w-100 mb-2">
                    <i class="bi bi-pencil"></i> Edit Plan
                </a>
                <form action="{{ route('subscriptions.destroy', $plan) }}" method="POST"
                      onsubmit="return confirm('Are you sure you want to delete the plan &quot;{{ addslashes($plan->name) }}&quot;? This cannot be undone.');">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-outline-danger w-100"><i class="bi bi-trash"></i> Delete Plan</button>
                </form>
            </div>
        </div>
    </div>

    {{-- Details card --}}
    <div class="col-lg-8">
        <div class="card h-100">
            <div class="card-body p-4">
                <div class="row mb-3">
                    <div class="col-sm-3 text-muted">Plan ID</div>
                    <div class="col-sm-9 fw-semibold">#{{ $plan->id }}</div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-3 text-muted">Description</div>
                    <div class="col-sm-9">{{ $plan->description }}</div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-3 text-muted">Features</div>
                    <div class="col-sm-9">
                        <ul class="list-unstyled mb-0">
                            @foreach ($plan->features_list as $feature)
                                <li class="mb-1"><i class="bi bi-check-circle-fill text-success me-2"></i>{{ $feature }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-3 text-muted">Created</div>
                    <div class="col-sm-9">{{ $plan->created_at->format('d M Y, h:i A') }}</div>
                </div>
                <div class="row">
                    <div class="col-sm-3 text-muted">Last Updated</div>
                    <div class="col-sm-9">{{ $plan->updated_at->format('d M Y, h:i A') }}</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
