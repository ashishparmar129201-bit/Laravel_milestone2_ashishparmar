@extends('layouts.app')

@section('title', 'Subscription Plans')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold mb-0">Subscription Plans</h3>
    <a href="{{ route('subscriptions.create') }}" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Add New Plan
    </a>
</div>

<div class="card">
    <div class="card-body">

        {{-- Search + filter --}}
        <form method="GET" action="{{ route('subscriptions.index') }}" class="row g-2 mb-3">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" name="q" value="{{ request('q') }}" class="form-control"
                           placeholder="Search by ID, name, description, features or duration...">
                </div>
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select">
                    <option value="">All statuses</option>
                    <option value="Active" @selected(request('status') === 'Active')>Active</option>
                    <option value="Inactive" @selected(request('status') === 'Inactive')>Inactive</option>
                </select>
            </div>
            <div class="col-md-3">
                <button class="btn btn-dark">Search</button>
                @if (request()->hasAny(['q', 'status']))
                    <a href="{{ route('subscriptions.index') }}" class="btn btn-outline-secondary">Reset</a>
                @endif
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Duration</th>
                        <th>Features</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                @forelse ($plans as $plan)
                    <tr>
                        <td>{{ $plan->id }}</td>
                        <td class="fw-semibold">{{ $plan->name }}</td>
                        <td>${{ number_format($plan->price, 2) }}</td>
                        <td><span class="badge bg-info-subtle text-info-emphasis">{{ $plan->duration }}</span></td>
                        <td>
                            @foreach (array_slice($plan->features_list, 0, 3) as $feature)
                                <span class="badge bg-light text-dark border">{{ $feature }}</span>
                            @endforeach
                            @if (count($plan->features_list) > 3)
                                <span class="text-muted small">+{{ count($plan->features_list) - 3 }} more</span>
                            @endif
                        </td>
                        <td>
                            <span class="badge {{ $plan->status === 'Active' ? 'bg-success' : 'bg-secondary' }}">{{ $plan->status }}</span>
                        </td>
                        <td class="text-end text-nowrap">
                            <a href="{{ route('subscriptions.show', $plan) }}" class="btn btn-sm btn-outline-info" title="View"><i class="bi bi-eye"></i></a>
                            <a href="{{ route('subscriptions.edit', $plan) }}" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                            <form action="{{ route('subscriptions.destroy', $plan) }}" method="POST" class="d-inline"
                                  onsubmit="return confirm('Are you sure you want to delete the plan &quot;{{ addslashes($plan->name) }}&quot;? This cannot be undone.');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="7" class="text-center text-muted py-4">No subscription plans found.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-between align-items-center">
            <small class="text-muted">Showing {{ $plans->firstItem() ?? 0 }}–{{ $plans->lastItem() ?? 0 }} of {{ $plans->total() }}</small>
            {{ $plans->links() }}
        </div>
    </div>
</div>
@endsection
