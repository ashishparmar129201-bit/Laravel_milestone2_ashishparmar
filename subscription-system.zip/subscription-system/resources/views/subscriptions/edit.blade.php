@extends('layouts.app')

@section('title', 'Edit Plan')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold mb-0">Edit Plan: {{ $plan->name }}</h3>
    <a href="{{ route('subscriptions.index') }}" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Back to Plans
    </a>
</div>

<div class="card">
    <div class="card-body p-4">
        <form action="{{ route('subscriptions.update', $plan) }}" method="POST" novalidate>
            @csrf
            @method('PUT')

            @include('subscriptions._form', ['plan' => $plan])

            <div class="mt-4">
                <button type="submit" class="btn btn-primary px-4"><i class="bi bi-check2-circle"></i> Update Plan</button>
                <a href="{{ route('subscriptions.index') }}" class="btn btn-light">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
