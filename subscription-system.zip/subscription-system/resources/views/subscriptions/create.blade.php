@extends('layouts.app')

@section('title', 'Add Plan')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold mb-0">Add Subscription Plan</h3>
    <a href="{{ route('subscriptions.index') }}" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Back to Plans
    </a>
</div>

<div class="card">
    <div class="card-body p-4">
        <form action="{{ route('subscriptions.store') }}" method="POST" novalidate>
            @csrf

            @include('subscriptions._form', ['plan' => null])

            <div class="mt-4">
                <button type="submit" class="btn btn-primary px-4"><i class="bi bi-save"></i> Save Plan</button>
                <a href="{{ route('subscriptions.index') }}" class="btn btn-light">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
