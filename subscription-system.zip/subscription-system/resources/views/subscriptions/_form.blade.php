{{-- Shared form fields used by create.blade.php and edit.blade.php --}}
@php($plan = $plan ?? null)

@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Please fix the following errors:</strong>
        <ul class="mb-0 mt-1">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="row g-3">
    <div class="col-md-6">
        <label for="name" class="form-label fw-semibold">Plan Name <span class="text-danger">*</span></label>
        <input type="text" id="name" name="name" value="{{ old('name', $plan?->name) }}"
               class="form-control @error('name') is-invalid @enderror" placeholder="e.g. Pro Monthly">
        @error('name') <div class="invalid-feedback">{{ $message }}</div> @enderror
    </div>

    <div class="col-md-6">
        <label for="price" class="form-label fw-semibold">Plan Price ($) <span class="text-danger">*</span></label>
        <input type="number" step="0.01" min="0" id="price" name="price" value="{{ old('price', $plan?->price) }}"
               class="form-control @error('price') is-invalid @enderror" placeholder="e.g. 29.99">
        @error('price') <div class="invalid-feedback">{{ $message }}</div> @enderror
    </div>

    <div class="col-md-6">
        <label for="duration" class="form-label fw-semibold">Duration <span class="text-danger">*</span></label>
        <select id="duration" name="duration" class="form-select @error('duration') is-invalid @enderror">
            <option value="">-- Select duration --</option>
            @foreach (\App\Models\SubscriptionPlan::DURATIONS as $d)
                <option value="{{ $d }}" @selected(old('duration', $plan?->duration) === $d)>{{ $d }}</option>
            @endforeach
        </select>
        @error('duration') <div class="invalid-feedback">{{ $message }}</div> @enderror
    </div>

    <div class="col-md-6">
        <label for="status" class="form-label fw-semibold">Status <span class="text-danger">*</span></label>
        <select id="status" name="status" class="form-select @error('status') is-invalid @enderror">
            @foreach (\App\Models\SubscriptionPlan::STATUSES as $s)
                <option value="{{ $s }}" @selected(old('status', $plan?->status ?? 'Active') === $s)>{{ $s }}</option>
            @endforeach
        </select>
        @error('status') <div class="invalid-feedback">{{ $message }}</div> @enderror
    </div>

    <div class="col-12">
        <label for="description" class="form-label fw-semibold">Plan Description <span class="text-danger">*</span></label>
        <textarea id="description" name="description" rows="3"
                  class="form-control @error('description') is-invalid @enderror"
                  placeholder="Describe the plan (min 10 characters)">{{ old('description', $plan?->description) }}</textarea>
        @error('description') <div class="invalid-feedback">{{ $message }}</div> @enderror
    </div>

    <div class="col-12">
        <label for="features" class="form-label fw-semibold">Features <span class="text-danger">*</span></label>
        <textarea id="features" name="features" rows="5"
                  class="form-control @error('features') is-invalid @enderror"
                  placeholder="Enter one feature per line&#10;e.g.&#10;5 Users&#10;50 GB Storage">{{ old('features', $plan?->features) }}</textarea>
        <div class="form-text">Write each feature on a new line.</div>
        @error('features') <div class="invalid-feedback">{{ $message }}</div> @enderror
    </div>
</div>
