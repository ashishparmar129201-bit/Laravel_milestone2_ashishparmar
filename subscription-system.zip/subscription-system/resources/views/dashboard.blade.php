@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-0">Dashboard</h3>
        <small class="text-muted">Overview of your subscription plans</small>
    </div>
    <a href="{{ route('subscriptions.create') }}" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Add New Plan
    </a>
</div>

{{-- Statistic cards --}}
<div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card"><div class="card-body d-flex align-items-center">
            <div class="stat-icon bg-primary-subtle text-primary me-3"><i class="bi bi-collection"></i></div>
            <div><div class="text-muted small">Total Plans</div><div class="fs-3 fw-bold">{{ $stats['total'] }}</div></div>
        </div></div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card"><div class="card-body d-flex align-items-center">
            <div class="stat-icon bg-success-subtle text-success me-3"><i class="bi bi-check-circle"></i></div>
            <div><div class="text-muted small">Active Plans</div><div class="fs-3 fw-bold">{{ $stats['active'] }}</div></div>
        </div></div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card"><div class="card-body d-flex align-items-center">
            <div class="stat-icon bg-danger-subtle text-danger me-3"><i class="bi bi-x-circle"></i></div>
            <div><div class="text-muted small">Inactive Plans</div><div class="fs-3 fw-bold">{{ $stats['inactive'] }}</div></div>
        </div></div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card"><div class="card-body d-flex align-items-center">
            <div class="stat-icon bg-warning-subtle text-warning me-3"><i class="bi bi-currency-dollar"></i></div>
            <div><div class="text-muted small">Average Price</div><div class="fs-3 fw-bold">${{ number_format($stats['average'], 2) }}</div></div>
        </div></div>
    </div>
</div>

{{-- Charts --}}
<div class="row g-3 mb-4">
    <div class="col-lg-5">
        <div class="card h-100"><div class="card-body">
            <h6 class="fw-bold">Active vs Inactive</h6>
            <canvas id="statusChart" height="220"></canvas>
        </div></div>
    </div>
    <div class="col-lg-7">
        <div class="card h-100"><div class="card-body">
            <h6 class="fw-bold">Plans by Duration</h6>
            <canvas id="durationChart" height="150"></canvas>
            <div class="text-muted small mt-3">Highest priced plan: <strong>${{ number_format($stats['highest'], 2) }}</strong></div>
        </div></div>
    </div>
</div>

{{-- Recent plans --}}
<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between mb-3">
            <h6 class="fw-bold mb-0">Recently Added Plans</h6>
            <a href="{{ route('subscriptions.index') }}" class="small">View all</a>
        </div>
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead class="table-light">
                    <tr><th>ID</th><th>Name</th><th>Price</th><th>Duration</th><th>Status</th></tr>
                </thead>
                <tbody>
                @forelse ($recentPlans as $plan)
                    <tr>
                        <td>{{ $plan->id }}</td>
                        <td><a href="{{ route('subscriptions.show', $plan) }}" class="text-decoration-none fw-semibold">{{ $plan->name }}</a></td>
                        <td>${{ number_format($plan->price, 2) }}</td>
                        <td>{{ $plan->duration }}</td>
                        <td><span class="badge {{ $plan->status === 'Active' ? 'bg-success' : 'bg-secondary' }}">{{ $plan->status }}</span></td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="text-center text-muted py-3">No plans yet.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script>
    new Chart(document.getElementById('statusChart'), {
        type: 'doughnut',
        data: {
            labels: ['Active', 'Inactive'],
            datasets: [{ data: [{{ $stats['active'] }}, {{ $stats['inactive'] }}], backgroundColor: ['#198754', '#adb5bd'] }]
        },
        options: { plugins: { legend: { position: 'bottom' } } }
    });

    new Chart(document.getElementById('durationChart'), {
        type: 'bar',
        data: {
            labels: @json(array_keys($durationCounts)),
            datasets: [{ label: 'Number of plans', data: @json(array_values($durationCounts)), backgroundColor: '#4338ca', borderRadius: 6 }]
        },
        options: { scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }, plugins: { legend: { display: false } } }
    });
</script>
@endpush
