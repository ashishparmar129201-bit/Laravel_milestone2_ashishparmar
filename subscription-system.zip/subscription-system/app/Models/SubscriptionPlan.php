<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class SubscriptionPlan extends Model
{
    protected $table = 'subscription_plans';

    protected $fillable = [
        'name',
        'description',
        'price',
        'duration',
        'features',
        'status',
    ];

    protected $casts = [
        'price' => 'decimal:2',
    ];

    public const DURATIONS = ['Monthly', 'Quarterly', 'Yearly'];
    public const STATUSES  = ['Active', 'Inactive'];

    /** Features are stored one per line; return them as a clean array. */
    public function getFeaturesListAttribute(): array
    {
        return array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) $this->features))));
    }

    /** Search by ID, name, description, features or duration. */
    public function scopeSearch(Builder $query, ?string $term): Builder
    {
        if (!$term) {
            return $query;
        }

        return $query->where(function (Builder $q) use ($term) {
            $q->where('name', 'like', "%{$term}%")
              ->orWhere('description', 'like', "%{$term}%")
              ->orWhere('features', 'like', "%{$term}%")
              ->orWhere('duration', 'like', "%{$term}%");

            if (ctype_digit($term)) {
                $q->orWhere('id', (int) $term);
            }
        });
    }
}
