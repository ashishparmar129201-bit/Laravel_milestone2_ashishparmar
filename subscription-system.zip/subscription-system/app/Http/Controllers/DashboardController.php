<?php

namespace App\Http\Controllers;

use App\Models\SubscriptionPlan;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total'    => SubscriptionPlan::count(),
            'active'   => SubscriptionPlan::where('status', 'Active')->count(),
            'inactive' => SubscriptionPlan::where('status', 'Inactive')->count(),
            'average'  => (float) SubscriptionPlan::avg('price'),
            'highest'  => (float) SubscriptionPlan::max('price'),
        ];

        $byDuration = SubscriptionPlan::selectRaw('duration, COUNT(*) as total')
            ->groupBy('duration')
            ->pluck('total', 'duration');

        $durationCounts = [];
        foreach (SubscriptionPlan::DURATIONS as $d) {
            $durationCounts[$d] = (int) ($byDuration[$d] ?? 0);
        }

        $recentPlans = SubscriptionPlan::latest()->take(5)->get();

        return view('dashboard', compact('stats', 'durationCounts', 'recentPlans'));
    }
}
