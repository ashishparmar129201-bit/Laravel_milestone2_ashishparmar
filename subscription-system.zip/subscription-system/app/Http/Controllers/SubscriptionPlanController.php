<?php

namespace App\Http\Controllers;

use App\Models\SubscriptionPlan;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SubscriptionPlanController extends Controller
{
    /** Validation rules shared by store() and update(). */
    private function rules(?int $ignoreId = null): array
    {
        return [
            'name'        => ['required', 'string', 'min:3', 'max:100',
                              Rule::unique('subscription_plans', 'name')->ignore($ignoreId)],
            'description' => ['required', 'string', 'min:10', 'max:1000'],
            'price'       => ['required', 'numeric', 'min:0', 'max:99999999.99'],
            'duration'    => ['required', Rule::in(SubscriptionPlan::DURATIONS)],
            'features'    => ['required', 'string', 'min:3', 'max:2000'],
            'status'      => ['required', Rule::in(SubscriptionPlan::STATUSES)],
        ];
    }

    /** List all plans (with search + status filter). */
    public function index(Request $request)
    {
        $plans = SubscriptionPlan::query()
            ->search($request->query('q'))
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->query('status')))
            ->orderBy('id', 'desc')
            ->paginate(10)
            ->withQueryString();

        return view('subscriptions.index', compact('plans'));
    }

    /** Show the "add plan" form. */
    public function create()
    {
        return view('subscriptions.create');
    }

    /** Save a new plan. */
    public function store(Request $request)
    {
        $data = $request->validate($this->rules());

        SubscriptionPlan::create($data);

        return redirect()->route('subscriptions.index')
            ->with('success', 'Subscription plan created successfully.');
    }

    /** Show one plan. */
    public function show(SubscriptionPlan $subscription)
    {
        return view('subscriptions.show', ['plan' => $subscription]);
    }

    /** Show the "edit plan" form. */
    public function edit(SubscriptionPlan $subscription)
    {
        return view('subscriptions.edit', ['plan' => $subscription]);
    }

    /** Update a plan. */
    public function update(Request $request, SubscriptionPlan $subscription)
    {
        $data = $request->validate($this->rules($subscription->id));

        $subscription->update($data);

        return redirect()->route('subscriptions.index')
            ->with('success', 'Subscription plan updated successfully.');
    }

    /** Delete a plan. */
    public function destroy(SubscriptionPlan $subscription)
    {
        $subscription->delete();

        return redirect()->route('subscriptions.index')
            ->with('success', 'Subscription plan deleted successfully.');
    }
}
