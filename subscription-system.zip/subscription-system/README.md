# Subscription Plan Management System (Laravel 11/12 + MySQL + Bootstrap 5)

## 1. Requirements
PHP 8.2+, Composer, MySQL 8 (or MariaDB / XAMPP / Laragon).

## 2. Create the Laravel project
    composer create-project laravel/laravel subscription-system
    cd subscription-system

## 3. Create the MySQL database
    mysql -u root -p
    CREATE DATABASE subscription_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    EXIT;
(or create `subscription_db` in phpMyAdmin)

## 4. Configure .env
Copy the lines from `env-database-snippet.txt` into the project's `.env`
(Laravel 11+ defaults to SQLite, so DB_CONNECTION must be changed to mysql).

## 5. Copy the files into the project (same relative paths)
| From this folder | To the Laravel project |
|---|---|
| database/migrations/2026_01_01_000000_create_subscription_plans_table.php | database/migrations/ |
| database/seeders/SubscriptionPlanSeeder.php | database/seeders/ |
| database/seeders/DatabaseSeeder.php | database/seeders/ (overwrite) |
| app/Models/SubscriptionPlan.php | app/Models/ |
| app/Http/Controllers/DashboardController.php | app/Http/Controllers/ |
| app/Http/Controllers/SubscriptionPlanController.php | app/Http/Controllers/ |
| app/Providers/AppServiceProvider.php | app/Providers/ (overwrite) |
| routes/web.php | routes/ (overwrite) |
| resources/views/layouts/app.blade.php | resources/views/layouts/ |
| resources/views/dashboard.blade.php | resources/views/ |
| resources/views/subscriptions/*.blade.php (index, create, edit, show, _form) | resources/views/subscriptions/ |

## 6. Run
    php artisan migrate --seed
    php artisan serve
Open http://127.0.0.1:8000

`migrate --seed` creates the table and adds 5 sample plans. Use `php artisan migrate:fresh --seed` to reset.

## Troubleshooting
- "Access denied" / "Unknown database": check DB_* values in .env, then `php artisan config:clear`.
- Page not found after copying routes: `php artisan route:clear`.
