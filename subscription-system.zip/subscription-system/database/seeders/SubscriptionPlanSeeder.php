<?php

namespace Database\Seeders;

use App\Models\SubscriptionPlan;
use Illuminate\Database\Seeder;

class SubscriptionPlanSeeder extends Seeder
{
    public function run(): void
    {
        $plans = [
            ['Basic Monthly', 'Perfect for individuals getting started with our service.', 9.99, 'Monthly',
             "1 User\n5 GB Storage\nEmail Support", 'Active'],
            ['Pro Monthly', 'Great for freelancers and small teams who need more power.', 24.99, 'Monthly',
             "5 Users\n50 GB Storage\nPriority Email Support\nBasic Analytics", 'Active'],
            ['Business Quarterly', 'Ideal for growing businesses, billed every three months.', 69.99, 'Quarterly',
             "20 Users\n200 GB Storage\n24/7 Chat Support\nAdvanced Analytics", 'Active'],
            ['Enterprise Yearly', 'Full-featured plan for large organizations with yearly billing.', 599.00, 'Yearly',
             "Unlimited Users\n1 TB Storage\nDedicated Account Manager\nCustom Integrations\nSLA Guarantee", 'Active'],
            ['Starter Yearly (Legacy)', 'Old yearly starter plan kept for existing customers.', 89.00, 'Yearly',
             "2 Users\n10 GB Storage\nEmail Support", 'Inactive'],
        ];

        foreach ($plans as [$name, $description, $price, $duration, $features, $status]) {
            SubscriptionPlan::updateOrCreate(
                ['name' => $name],
                compact('description', 'price', 'duration', 'features', 'status')
            );
        }
    }
}
